OMAR ♡ NOURHAN — LOVE LICENSE
================================

This is the first complete single-file version of the interactive gift website.

Main file:
- index.html

The site is self-contained:
- The two uploaded memory photos are embedded.
- The Love Case and Omar Museum PDFs are embedded.
- The Gifft.me memory is linked.
- The final song is the official YouTube video for Fadel Chaker — Ahla Rasma.

GitHub Pages:
1. Upload index.html to the root of your repository.
2. GitHub -> Settings -> Pages.
3. Choose Deploy from a branch.
4. Select main + /(root), then Save.
5. Wait for GitHub Pages to publish.

Important:
The password is a front-end gate, not real security. GitHub Pages sites are publicly reachable by URL.
